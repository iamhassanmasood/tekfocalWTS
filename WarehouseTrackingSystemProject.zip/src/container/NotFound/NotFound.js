import React, { Component } from 'react';

export default class NotFound extends Component {
    render() {
        return (
                <div style={{position: "absolute", height: "50px", top: '50%', left: "50%", marginLeft: "-100px" }}>
                    <h3>404 Page Not Found</h3>
                </div>

        )
    }
}
