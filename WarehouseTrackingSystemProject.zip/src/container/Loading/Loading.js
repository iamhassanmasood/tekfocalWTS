import React from 'react';
import {PassThrouthLoading} from 'react-loadingg';
const Loading = () =><PassThrouthLoading size="small" color="#023e58"/>;
export default Loading;